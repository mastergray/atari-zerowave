#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 mastergray
# SPDX-License-Identifier: GPL-3.0-only

"""Run deterministic display scenarios in Stella's real TIA implementation.

Run with a display, or: xvfb-run -a python3 tools/verify_stella.py
Collected emulator state and captures are stored under build/stella/.
"""
import argparse
import json

from stella_session import ROOT, run_stella


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeout", type=float, default=45)
    args = parser.parse_args()
    commands = []
    labels, advances = [], []

    def frame(count=1):
        commands.extend([f"frame #{count}", "print _cycleslo"])
        advances.append(count)

    def capture(label):
        # DisplayPattern still describes the completed frame at the VSYNC stop;
        # gameplay counters already describe the next frame's update.
        commands.extend(["print *DisplayPattern", "print *ArenaColor", "savesnap"])
        labels.append(label)

    frame(5)
    capture("neutral")
    directions = [("N", ["up"]), ("NE", ["up", "right"]), ("E", ["right"]), ("SE", ["down", "right"]),
                  ("S", ["down"]), ("SW", ["down", "left"]), ("W", ["left"]), ("NW", ["up", "left"])]
    for name, held in directions:
        for direction in ("up", "down", "left", "right"):
            # Debugger commands set electrical pin levels: zero is pressed.
            commands.append(f"joy0{direction} #{int(direction not in held)}")
        frame(2)
        commands.append("print *Direction")
        capture(f"{name}-0")
        frame()
        capture(f"{name}-1")
    commands.append("joy0fire #0")
    frame()
    commands.extend(["print *BombCount", "print *BombCooldown"])
    # Capture all 16 completed animation frames, including interleaved beams.
    for elapsed in range(16):
        frame()
        capture(f"bomb-{elapsed:02}")
    frame(49)
    commands.extend(["print *BombCount", "print *BombCooldown", "joy0fire #1"])
    frame()
    # Stella 6 has no SELECT debugger command. Drive just port B's SELECT bit
    # as an output in this test; the ROM still samples SWCHB and detects edges.
    commands.append("ram SWBCNT #2")
    for _ in range(8):
        commands.append("ram SWCHB $FD")
        frame()
        commands.append("ram SWCHB $FF")
        frame()
    for layout in ("same-height", "near-turret", "north-south"):
        if layout != "same-height":
            commands.append("ram SWCHB $FD")
            frame()
            commands.append("ram SWCHB $FF")
            frame()
        commands.extend(["print *LayoutId", "joy0fire #0"])
        frame()
        commands.append("print *BombCount")
        frame(13)  # largest ring, with both enemy phases across the next two captures
        commands.append("print *SelectedSlot")
        capture(f"{layout}-0")
        frame()
        commands.append("print *SelectedSlot")
        capture(f"{layout}-1")
        commands.append("joy0fire #1")
        frame(48)  # release and recover before the next layout's bomb
    commands.append("ram SWBCNT #0")
    # Release after holding NW. The first stop shows the last bright frame;
    # the following 15 captures show the original Laser Blast decay cadence.
    for direction in ("up", "down", "left", "right"):
        commands.append(f"joy0{direction} #1")
    frame()
    commands.extend(["print *BeamEnabled", "print *BeamFadeHue"])
    capture("fade-held")
    for elapsed in range(15):
        frame()
        commands.append("print *BeamEnabled")
        capture(f"fade-{elapsed:02}")
    frame()
    commands.append("print *BeamEnabled")
    capture("fade-finished")
    commands.append("print _fcount")
    run, values, snapshots, transcript = run_stella("atari-zerowave-display", commands, labels, advances, args.timeout)
    out = run.parent
    assert values("*Direction") == list(range(8)), values("*Direction")
    assert values("*BombCount") == [1, 1, 2, 3, 4], values("*BombCount")
    assert values("*BombCooldown") == [30, 0], values("*BombCooldown")
    assert values("*LayoutId") == [8, 9, 10], values("*LayoutId")
    slots = values("*SelectedSlot")
    assert len(slots) == 6 and all(set(slots[i:i + 2]) == {0, 1} for i in (0, 2, 4)), slots
    patterns = values("*DisplayPattern")
    assert len(patterns) == len(labels) and patterns[0] == 8, patterns
    colors = values("*ArenaColor")
    assert len(colors) == len(labels), colors
    for direction in range(8):
        start = 1 + direction * 2
        assert patterns[start:start + 2] == [direction, direction], patterns
        assert all(color & 15 == 14 for color in colors[start:start + 2]), colors
    bomb_patterns = patterns[17:33]
    assert [p for p in bomb_patterns if p >= 9] == [9, 9, 10, 10, 11, 11, 12, 12], bomb_patterns
    assert bomb_patterns.count(7) == 8, bomb_patterns
    for i in (33, 35, 37):
        assert sorted(patterns[i:i + 2]) == [7, 12], patterns
    fade_hue = values("*BeamFadeHue")[0]
    assert patterns[39:] == [7] * 16 + [8], patterns[39:]
    assert colors[39] & 15 == 14 and colors[39] & 0xf0 == fade_hue, colors[39:]
    assert colors[40:55] == [fade_hue | level for level in range(15, 0, -1)], colors[40:55]
    assert colors[55] == 0, colors[55]
    assert values("*BeamEnabled") == [0] * 17, values("*BeamEnabled")
    assert all(color == 46 for pattern, color in zip(patterns, colors) if pattern >= 9), colors
    cycles = values("_cycleslo")
    assert len(cycles) == len(advances), (cycles, advances)
    assert all(b - a == count * 262 * 76 for a, b, count in zip(cycles, cycles[1:], advances[1:])), cycles
    report = {"directory": str(run.relative_to(ROOT)), "snapshots": dict(zip(labels, [p.name for p in snapshots])), "session": transcript.name,
              "frame_lines": 262, "cycles_per_frame": 262 * 76, "direction_ids": values("*Direction"),
              "bomb_count_after_held_button": values("*BombCount")[1],
              "display_patterns": dict(zip(labels, patterns)), "arena_colors": dict(zip(labels, colors)),
              "fade_frames": 15, "fade_beam_enabled": False}
    (out / "latest.json").write_text(json.dumps(report, indent=2) + "\n")
    print(f"Stella executed the scenarios and captured {len(snapshots)} TIA images in {run}")
    print(f"Debugger results: {transcript}")


if __name__ == "__main__":
    main()
